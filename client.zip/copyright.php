<!DOCTYPE html>
<html lang="en">
<head>
</head>


<body>
    
    <div class="text-center my-auto copyright"><span>Copyright © SellEASP <?php echo date('Y'); ?></span> Powered by <a href="https://epfintech.com" target="_blank" style="font-weight: bold;color:red;">EP Fintech Solution Ltd</a></div>
    
</body>
</html>