<?php

//localhost Connection
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "newdb";

?>