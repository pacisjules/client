<?php
$globalVariable = "/selleasepPanel/functions/";

function theFunctionGlobal() {
    global $globalVariable;
}

theFunctionGlobal();
?>